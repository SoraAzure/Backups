String.prototype.isGmail = function() {
    return /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@gmail\.com$/.test(this);
}

String.prototype.isPhone = function() {
    return /^\d{8}$/.test(this);
}
