$.fn.envData = function(suffix) {
    var name = "data-{0}".args(suffix);
    return $(this).attr(name) || $(this).closest("[{0}]".args(name)).attr(name);
};
$.fn.envDataProvider = function(suffix) {
    var name = "data-{0}".args(suffix);
    return $(this).attr(name) ? this : $(this).closest("[{0}]".args(name));
};
$.fn.activateMutex = function() {
    $(this).each(function() {
        var name = $(this).attr("data-mutex-name");
        if(name) {
            var group = $(this).closest("[data-mutex-group]");
            var filter = function() {
                return $(this).closest("[data-mutex-group]").is(group);
            };
            var mutexes = group.find("[data-mutex-active]").filter(filter);
            group.find("[data-mutex-active]").filter(filter).removeAttr("data-mutex-active");
            $(this).attr("data-mutex-active", "data-mutex-active");
            group.find("[data-mutex-name]").filter(filter).filter("[data-mutex-name!='{0}']".args(name)).hide();
            group.find("[data-mutex-name='{0}']".args(name)).filter(filter).show();
        }
    });
    return this;
};
$.fn.isMutexActive = function() {
    return $(this).attr("data-mutex-active") != null;
}
$.fn.updateTo = function() {
    $(this).each(function() {
        var tag = $(this).prop("tagName");
        if($.inArray($(this).prop("tagName"), [ "INPUT", "SELECT", "OPTION", "TEXTAREA" ]) != -1)
            $(this).attr("data-value", stringify($(this).val()));
        else
            $(this).attr("data-value", stringify($(this).text()));
    });
    return this;
};
$.fn.updateFrom = function() {
    $(this).each(function() {
        $(this).value(destringify($(this).attr("data-value")));
    });
    return this;
};
$.fn.value = function(val, keep) {
    var ctrl = [ "INPUT", "SELECT" ].includes($(this).prop("tagName"));
    var prop = ctrl ? $(this).val : $(this).text;
    if(!arguments.length) {
        if(!ctrl) {
            var ret = destringify($(this).attr("data-value"));
            return ret != null ? ret : prop.call($(this));
        } else {
            var ret = prop.call($(this));
            return ret != null ? ret : destringify($(this).attr("data-value"));
        }
    } else {
        $(this).each(function() {
            $(this).attr("data-value", stringify(val));
            var any = $(this).attr("data-any-formatter");
            var flexible = $(this).attr("data-flexible-formatter");
            var formatter = $(this).attr("data-formatter");
            var e = val;
            try {
                if(any)
                    eval(any);
                else {
                    if(!keep)
                        $(this).empty();
                    if(flexible)
                        eval(flexible);
                    else if(formatter)
                        prop.call($(this), eval(formatter));
                    else
                        prop.call($(this), val);
                }
            } catch(ex) {
                prop.call($(this), "");
            }
        });
        return this;
    }
};
$.fn.reset = function() {
    var ctrls = "INPUT, SELECT, OPTION, TEXTAREA";
    if(ctrls.indexOf($(this).prop("tagName")) != -1)
        $(this).value("");
    else {
        this.find(ctrls).each(function() {
            $(this).value("");
        });
    }
    return this;
};
