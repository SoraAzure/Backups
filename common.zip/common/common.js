stringify = function(obj) {
    try {
        return JSON.stringify(obj);
    } catch {
        return obj;
    }
};
destringify = function(str) {
    try {
        return JSON.parse(str);
    } catch {
        return str;
    }
};
Object.defineProperty(String.prototype, "args", {
    value: function() {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function(match, number) {
            return typeof args[number] != null ? args[number] : match;
        });
    }
});
Object.defineProperty(Array.prototype, "swap", {
    value: function(a, b) {
        this[a] = this.splice(b, 1, this[a])[0];
    }
});
Object.defineProperty(Date.prototype, "toStandardString", {
    value: function(utc) {
        var date = this;
        if(!utc) {
            var offset = this.getTimezoneOffset() * 60 * 1000;
            var local = this.getTime() - offset;
            date = new Date(local);
        }
        var str = date.toISOString();
        str = str.replace("T", " ").replace(/(\.\d+)|Z/g, "");
        return str;
    }
});
Object.defineProperty(Date.prototype, "toDateString", {
    value: function(utc) {
        var str = this.toStandardString();
        return str.split(/\s/)[0];
    }
});
Object.defineProperty(Date.prototype, "toTimeString", {
    value: function(utc) {
        var str = this.toStandardString();
        return str.split(/\s/)[1];
    }
});
