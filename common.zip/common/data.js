pidDataView = {
    "unused": [ "99991234", "99991235" ],
    "ungrouped": [ "99995678" ],
    "unassigned": [ "99992333" ],
    "assigned": [ "99990000", "99998888" ],
    "graduated": [ "99991111" ]
};

pidData = {
    "99991234": {
        "id": "99991234",
        "status": "unused",
        "gmail": "bme3s02.grp8.3@gmail.com",
        "mobile": "99991234"
    },
    "99991235": {
        "id": "99991235",
        "status": "unused",
        "gmail": "bme3s02.grp8.5@gmail.com",
        "mobile": "99991235"
    },
    "99995678": {
        "id": "99995678",
        "status": "ungrouped",
        "gmail": "bme3s02.grp8.1@gmail.com",
        "mobile": "99995678",
        "last_ip": "192.168.0.456",
        "personal_data": [
            {
                name: "sex",
                value: "male",
                all: [ "male", "female" ]
            },
            {
                name: "age",
                value: "70-74",
                all: [ "60-64", "65-69", "70-74", "75-79", "80+" ]
            },
            {
                name: "parq1",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq2",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq3",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq4",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq5",
                value: "true",
                all: [ "true", "false" ]
            },
            {
                name: "parq6",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq7",
                value: "true",
                all: [ "true", "false" ]
            }
        ]
    },
    "99992333": {
        "id": "99992333",
        "status": "unassigned",
        "gmail": "bme3s02.grp8.2gmail.com",
        "mobile": "99992333",
        "last_ip": "192.168.0.789",
        "personal_data": [
            {
                name: "sex",
                value: "male",
                all: [ "male", "female" ]
            },
            {
                name: "age",
                value: "70-74",
                all: [ "60-64", "65-69", "70-74", "75-79", "80+" ]
            },
            {
                name: "parq1",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq2",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq3",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq4",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq5",
                value: "true",
                all: [ "true", "false" ]
            },
            {
                name: "parq6",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq7",
                value: "true",
                all: [ "true", "false" ]
            }
        ],
        "group": "1",
        "finished_exercises": "2",
        "last_assigned_id": "2",
        "last_assigned_title": "Aerobics Example II (Level 1)",
        "begin_time": "1589145859000",
        "end_time": "1589145999000",
        "motion_data": [
                { time: "5123218725", heart: "90", calorie: "15" },
                { time: "5123218735", heart: "106", calorie: "25" },
                { time: "5123218745", heart: "70", calorie: "37" },
                { time: "5123218755", heart: "100", calorie: "42" },
                { time: "5123218765", heart: "120", calorie: "65" },
                { time: "5123218775", heart: "70", calorie: "67" },
                { time: "5123218785", heart: "70", calorie: "42" },
                { time: "5123218795", heart: "80", calorie: "49" },
                { time: "5123218815", heart: "85", calorie: "48" },
                { time: "3123218915", heart: "90", calorie: "15" },
                { time: "3123218105", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" }
        ],
        "feedback": "23"
    },
    "99990000": {
        "id": "99990000",
        "status": "assigned",
        "gmail": "bme3s02.grp8.2gmail.com",
        "mobile": "99990000",
        "last_ip": "192.168.0.666",
        "personal_data": [
            {
                name: "sex",
                value: "male",
                all: [ "male", "female" ]
            },
            {
                name: "age",
                value: "70-74",
                all: [ "60-64", "65-69", "70-74", "75-79", "80+" ]
            },
            {
                name: "parq1",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq2",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq3",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq4",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq5",
                value: "true",
                all: [ "true", "false" ]
            },
            {
                name: "parq6",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq7",
                value: "true",
                all: [ "true", "false" ]
            }
        ],
        "group": "1",
        "finished_exercises": "3",
        "last_assigned_id": "3",
        "last_assigned_title": "Aerobics Example III (Level 1)",
        "begin_time": "1589165859000",
        "end_time": "1589149999000",
        "motion_data": [
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218735", heart: "80", calorie: "16" },
                { time: "3123218745", heart: "86", calorie: "17" },
                { time: "3123218755", heart: "90", calorie: "30" },
                { time: "3123218765", heart: "110", calorie: "25" },
                { time: "3123218775", heart: "100", calorie: "17" },
                { time: "3123218785", heart: "70", calorie: "29" },
                { time: "3123218795", heart: "80", calorie: "15" },
                { time: "3123218815", heart: "85", calorie: "15" },
                { time: "3123218915", heart: "90", calorie: "15" },
                { time: "3123218105", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" }
        ],
        "feedback": "25",
        "feedback_memo": "can promote the level\nto be discussed",
        "arrangement": "new",
        "newly_assigned": "5",
        "operator": "Joe",
        "operated_time": "1589175859123",
        "notified": "Peter",
        "notified_time": "1589175858972"
    },
    "99998888": {
        "id": "99998888",
        "status": "assigned",
        "gmail": "bme3s09.grp8.2gmail.com",
        "mobile": "99998888",
        "last_ip": "192.168.0.666",
        "personal_data": [
            {
                name: "sex",
                value: "male",
                all: [ "male", "female" ]
            },
            {
                name: "age",
                value: "70-74",
                all: [ "60-64", "65-69", "70-74", "75-79", "80+" ]
            },
            {
                name: "parq1",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq2",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq3",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq4",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq5",
                value: "true",
                all: [ "true", "false" ]
            },
            {
                name: "parq6",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq7",
                value: "true",
                all: [ "true", "false" ]
            }
        ],
        "group": "1",
        "finished_exercises": "3",
        "last_assigned_id": "3",
        "last_assigned_title": "Aerobics Example III (Level 1)",
        "begin_time": "1589175859000",
        "end_time": "1589175999000",
        "motion_data": [
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218735", heart: "80", calorie: "20" },
                { time: "3123218745", heart: "86", calorie: "37" },
                { time: "3123218755", heart: "90", calorie: "42" },
                { time: "3123218765", heart: "110", calorie: "50" },
                { time: "3123218775", heart: "100", calorie: "62" },
                { time: "3123218785", heart: "70", calorie: "73" },
                { time: "3123218795", heart: "80", calorie: "15" },
                { time: "3123218815", heart: "85", calorie: "15" },
                { time: "3123218915", heart: "90", calorie: "15" },
                { time: "3123218105", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" },
                { time: "3123218725", heart: "75", calorie: "15" }
        ],
        "feedback": "25",
        "feedback_memo": "\ngood feedback\n\ntesting",
        "arrangement": "new",
        "newly_assigned": "5",
        "operator": "Joe",
        "operated_time": "1589175859000"
    },
    "99991111": {
        "id": "99991111",
        "status": "graduated",
        "gmail": "bme3s02.grp8.5gmail.com",
        "mobile": "99991111",
        "last_ip": "192.168.0.888",
        "personal_data": [
            {
                name: "sex",
                value: "male",
                all: [ "male", "female" ]
            },
            {
                name: "age",
                value: "70-74",
                all: [ "60-64", "65-69", "70-74", "75-79", "80+" ]
            },
            {
                name: "parq1",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq2",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq3",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq4",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq5",
                value: "true",
                all: [ "true", "false" ]
            },
            {
                name: "parq6",
                value: "false",
                all: [ "true", "false" ]
            },
            {
                name: "parq7",
                value: "true",
                all: [ "true", "false" ]
            }
        ],
        "group": "3",
        "finished_exercises": "8",
        "operator": "Joe",
        "operated_time": "362645345",
        "notified": "Mary",
        "notified_time": "3253255"
    }
};

pastVideoDataView = {
    "99992333": {
        "history": [ "1", "2" ]
    },
    "99990000": {
        "history": [ "4", "5" ]
    },
    "99998888": {
        "history": [ "2" ]
    },
    "99995678": {
        "history": [ "3" ]
    },
};

pastVideoData = {
    "99992333": {
        "1": {
            "video": "1",
            "pid": "99992333",
            "operator": "Joe",
            "operated_time": "1588073836000",
            "title": "Aerobics Example I (Level 1)",
            "begin_time": "1589063836000",
            "end_time": "1589072836000",
            "motion_data": [
                    { time: "3123218725", heart: "75", calorie: "15" },
                    { time: "3123218735", heart: "80", calorie: "17" },
                    { time: "3123218745", heart: "86", calorie: "23" },
                    { time: "3123218755", heart: "90", calorie: "27" },
                    { time: "3123218765", heart: "110", calorie: "15" },
                    { time: "3123218775", heart: "100", calorie: "15" },
                    { time: "3123218785", heart: "70", calorie: "48" },
                    { time: "3123218795", heart: "80", calorie: "17" },
                    { time: "3123218815", heart: "85", calorie: "10" },
                    { time: "3123218915", heart: "90", calorie: "30" },
                    { time: "3123218105", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" }
            ]
        },
        "2": {
            "video": "2",
            "pid": "99992333",
            "operator": "Mary",
            "operated_time": "1589073836000",
            "title": "Aerobics Example II (Level 1)",
            "begin_time": "1589145859000",
            "end_time": "1589145999000",
            "motion_data": [
                    { time: "5123218725", heart: "90", calorie: "15" },
                    { time: "5123218735", heart: "106", calorie: "25" },
                    { time: "5123218745", heart: "70", calorie: "37" },
                    { time: "5123218755", heart: "100", calorie: "42" },
                    { time: "5123218765", heart: "120", calorie: "65" },
                    { time: "5123218775", heart: "70", calorie: "67" },
                    { time: "5123218785", heart: "70", calorie: "42" },
                    { time: "5123218795", heart: "80", calorie: "49" },
                    { time: "5123218815", heart: "85", calorie: "48" },
                    { time: "3123218915", heart: "90", calorie: "15" },
                    { time: "3123218105", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" },
                    { time: "3123218725", heart: "75", calorie: "15" }
            ],
        }
    },
    "99990000": {
        "4": {
            "video": "1",
            "pid": "99990000",
            "operator": "Joe",
            "operated_time": "12345",
            "begin_time": "12345",
            "finish_time": "54321"
            
        },
        "5": {
            "video": "5",
            "pid": "99990000",
            "operator": "Joe",
            "operated_time": "12345"
        }
    },
    "99998888": {
        "2": {
            "video": "2",
            "pid": "99998888",
            "operator": "Joe",
            "operated_time": "12345"
        }
    },
    "99995678": {
        "3": {
            "video": "3",
            "pid": "99995678",
            "operator": "Joe",
            "operated_time": "12345"
        }
    },
};

videoDataView = {
    "intro": [],
    "group1": [ "1", "2", "4" ],
    "group2": [ "3" ],
    "group3": [ "5" ]
};

videoData = {
    "1": {
        "id": "1",
        "title": "Aerobics Example I",
        "file": "",
        "group": "1",
        "order": "1"
    },
    "2": {
        "id": "2",
        "title": "Aerobics Example II",
        "file": "",
        "group": "1",
        "order": "2"
    },
    "3": {
        "id": "3",
        "title": "Aerobics Example III",
        "file": "",
        "group": "1",
        "order": "2"
    },
    "4": {
        "id": "4",
        "title": "Aerobics Example IV",
        "file": "",
        "group": "1",
        "order": "2"
    },
    "5": {
        "id": "5",
        "title": "Aerobics Example V",
        "file": "",
        "group": "1",
        "order": "2"
    }
};

questionData = {
    "33": {
        "code": "moving_habit",
        "text": "你平時是坐得多，還是喜歡四處走動？",
        "type": "mc",
        "time": "30",
        "answers": {
            "sit": {
                "code": "sit",
                "text": "坐得多"
            },
            "move": {
                "code": "move",
                "text": "四處走動"
            },
            "all": {
                "code": "all",
                "text": "都有",
            }
        }
    },
    "125": {
        "code": "feedback",
        "text": "做完運動感覺如何？",
        "type": "audio",
        "time": "125"
    }
};

