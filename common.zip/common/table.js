Table = {};

Table.load = function(data, view, others) {
    for(var i in view) {
        var ids = view[i];
        var table = $("[data-section='{0}']".args(i));
        table.find("[data-id]").each(function() {
            var id = $(this).envData("id");
            if(!ids.includes(id)) {
                $(this).remove();
                Table.count(i, Table.count(i) - 1);
            }
        });
        var pos = 0;
        for(var j in ids) {
            var id = ids[j];
            var datum = data[id];
            if(others != null)
                datum = Object.assign({}, datum, others);
            Table.show(i, id, datum, pos);
            pos++;
        }
    }
};

Table.clear = function(section) {
    var table = $("[data-section='{0}']".args(section));
    table.find("[data-id]").remove();
    Table.count(section, 0);
}

Table.count = function(section, val) {
    var table = $("[data-section='{0}']".args(section));
    var count = parseInt(table.attr("data-row-count")) || 0;
    if(val == null)
        return count;
    table.attr("data-row-count", val);
    table.find(".section_row_count").value(val);
}

Table.show = function(section, id, datum, pos) {
    var table = $("[data-section='{0}']".args(section));
    if(id == null)
        id = Table.count(section);
    var row = table.find("[data-id='{0}']".args(id));
    if(!row.length) {
        row = table.find(".template").clone();
        row.removeClass("template");
        var insertion = table.find(".section_insertion");
        insertion.before(row);
        row.attr("data-id", id);
        row.find("[name*='$']").each(function() {
            var name = $(this).attr("name");
            $(this).attr("name", name.replace("$", id));
        });
        var count = Table.count(section);
        row.find("[data-from='#']").value(count);
        Table.count(section, count + 1);
    }
    var pairs = [];
    var others = Object.assign({}, datum);
    row.find("[data-from]").each(function() {
        var src = $(this).attr("data-from");
        if(src == "#")
            return;
        var data = datum[src];
        pairs.push({ cell: this, value: data });
        if(data != null)
            delete others[src];
    });
    row.attr("data-others", stringify(others));
    for(var i in pairs) {
        var pair = pairs[i];
        $(pair.cell).value(pair.value);
    }
    if(pos != null) {
        row.insertBefore(table.find("[data-id]").eq(pos));
        row.find("[data-from='#']").value(pos);
    }
};

Table.remove = function(section, id) {
    var table = $("[data-section='{0}']".args(section));
    var row = table.find("[data-id='{0}']".args(id));
    if(!row.length)
        return false;
    row.remove();
    Table.count(section, Table.count(section) - 1);
    return true;
};

Table.data = function(section, id, name, val) {
    var table = $("[data-section='{0}']".args(section));
    var arglen = arguments.length;
    if(arglen == 1) {
        var view = [];
        var data = {};
        table.find("[data-id]").each(function() {
            var id = $(this).attr("data-id");
            var entry = {};
            $(this).find("[data-from]").each(function() {
                var name = $(this).attr("data-from");
                var value = $(this).attr("data-value");
                entry[name] = value;
            });
            var others = destringify($(this).attr("data-others"));
            for(var i in others) {
                value = others[i];
                entry[i] = value;
            }
            view.push(id);
            data[id] = entry;
        });
        var ret = { view: view, data: data };
        return ret;
    }
    var row = table.find("[data-id='{0}']".args(id));
    var others = destringify(row.attr("data-others"));
    if(arglen == 2) {
        return;
    }
    var cell = row.find("[data-from='{0}']".args(name));
    if(arglen == 3) {
        if(!cell.length)
            return others[name];
        return cell.value();
    }
    if(arglen == 4) {
        if(!cell.length) {
            others[name] = val;
            row.attr("data-others", stringify(others));
        } else
            cell.value(val);
    }
};
